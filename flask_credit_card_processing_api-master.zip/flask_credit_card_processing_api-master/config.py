FLASK_SERVER = "0.0.0.0"
FLASK_PORT = 5000
FLASK_LOGGING = True

if __name__ == "__main__":
    print(FLASK_SERVER)
    print(FLASK_PORT)
    print(FLASK_LOGGING)
